import requests
import json
from pathlib import Path

# 1. 테스트 서버 주소
API_URL = "http://127.0.0.1:8000/analyze/"

# 2. 테스트 이미지 경로
IMAGE_PATH = Path("eiffel.jpg")  # 여기에 실제 이미지 파일명 입력

# 3. 질문 내용
QUESTION = "이 음식 이름 뭐야?"

# 4. 파일 존재 확인
if not IMAGE_PATH.exists():
    print(f"[ERROR] 파일을 찾을 수 없습니다: {IMAGE_PATH}")
    exit(1)

# 5. multipart/form-data 구성
files = {
    "image": (IMAGE_PATH.name, IMAGE_PATH.open("rb"), "image/jpeg")
}
data = {
    "question": QUESTION
}

# 6. 요청 전송
print("[INFO] 요청 전송 중...")
response = requests.post(API_URL, files=files, data=data)

# 7. 응답 결과 출력
print(f"[STATUS] HTTP {response.status_code}")
if response.status_code == 200:
    resp_json = response.json()
    print("[✅ 결과]")
    print(json.dumps(resp_json, indent=2, ensure_ascii=False))
else:
    print("[❌ 에러]")
    print(response.text)
