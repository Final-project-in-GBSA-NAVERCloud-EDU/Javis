import boto3
import os
from dotenv import load_dotenv
import requests

# 1. 환경 변수 로드
load_dotenv()

access_key = os.getenv("NCLOUD_ACCESS_KEY")
secret_key = os.getenv("NCLOUD_SECRET_KEY")
endpoint_url = os.getenv("NCLOUD_S3_ENDPOINT")
bucket = os.getenv("NCLOUD_BUCKET")

filename = "object.csv"
object_key = f"test/{filename}"
upload_data = b"test file\n1,2\n3,4"

# 2. boto3 클라이언트
s3 = boto3.client(
    "s3",
    aws_access_key_id=access_key,
    aws_secret_access_key=secret_key,
    endpoint_url=endpoint_url,
    config=boto3.session.Config(signature_version="s3v4")
)

# 3. presigned PUT URL 생성
try:
    presigned_url = s3.generate_presigned_url(
        'put_object',
        Params={
            'Bucket': bucket,
            'Key': object_key,
            'ContentType': 'text/csv',
        },
        ExpiresIn=300  # seconds
    )

    print("🔗 Generated presigned PUT URL:\n", presigned_url)

    # 4. 실제로 PUT 요청 보내기 (직접 HTTP)
    headers = {
        "Content-Type": "text/csv"
    }
    response = requests.put(presigned_url, data=upload_data, headers=headers)

    print("\n📤 PUT 요청 결과:", response.status_code)
    if response.ok:
        print("✅ 업로드 성공!")
    else:
        print("❌ 실패:", response.text)

except Exception as e:
    print("오류 발생:", e)
