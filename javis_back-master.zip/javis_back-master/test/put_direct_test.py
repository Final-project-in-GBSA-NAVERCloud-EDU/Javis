import boto3, os, uuid, datetime
from dotenv import load_dotenv
import requests
from mimetypes import guess_type
from pathlib import Path

# 1. 환경 변수 로드
load_dotenv()

access_key = os.getenv("NCLOUD_ACCESS_KEY")
secret_key = os.getenv("NCLOUD_SECRET_KEY")
endpoint_url = os.getenv("NCLOUD_S3_ENDPOINT")
bucket = os.getenv("NCLOUD_BUCKET")

# 2. 업로드할 이미지 파일 경로 (여기서 파일을 바꿔주세요)
image_path = Path("eiffel.jpg")  # 예: sample/test.png
if not image_path.exists():
    raise FileNotFoundError(f"{image_path} 파일이 존재하지 않습니다.")

# 3. 파일 확장자로 Content-Type 추론 (예: image/jpeg)
content_type, _ = guess_type(image_path)
if content_type is None:
    content_type = "application/octet-stream"  # 기본값 fallback

# 4. object key 생성 경로
key_prefix = datetime.datetime.utcnow().strftime("%Y/%m/%d/%H/%M/")
object_key = f"{key_prefix}{uuid.uuid4()}_{image_path.name}"

# 5. boto3 S3 클라이언트
s3 = boto3.client(
    "s3",
    aws_access_key_id=access_key,
    aws_secret_access_key=secret_key,
    endpoint_url=endpoint_url,
    config=boto3.session.Config(signature_version="s3v4")
)

# 6. presigned URL 생성 → 이미지 UPLOAD 요청
try:
    presigned_url = s3.generate_presigned_url(
        'put_object',
        Params={
            'Bucket': bucket,
            'Key': object_key,
            'ContentType': content_type,
        },
        ExpiresIn=300  # URL 유효 시간 (초)
    )

    print("🔗 Generated presigned PUT URL:\n", presigned_url)

    # 7. 이미지 파일 열기 & put 요청
    with image_path.open("rb") as image_file:
        response = requests.put(
            presigned_url,
            data=image_file,
            headers={"Content-Type": content_type}
        )

    print("\n📤 PUT 요청 결과:", response.status_code)
    if response.ok:
        print("✅ 이미지 업로드 성공!", f"\n🪪 Key: {object_key}")
    else:
        print("❌ 실패:", response.text)

except Exception as e:
    print("오류 발생:", e)
