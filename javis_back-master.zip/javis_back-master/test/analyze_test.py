import requests
from pathlib import Path

# --- 설정 ---

API_URL = "http://127.0.0.1:8000/analyze/"  # FastAPI 서버가 이 주소/포트에서 실행 중 이어야 함
IMG_PATH = Path("eiffel.jpg")               # 테스트 할 이미지 파일 경로
QUESTION = "AI야 이 건물은 어디인지 대답해"
CONVERSATION_ID = ""  # 기존 대화 ID가 있으면 넣고, 아니면 비워두세요

# --- 이미지 파일 존재 확인 ---
if not IMG_PATH.exists():
    raise FileNotFoundError(f"❌ {IMG_PATH} 파일이 존재하지 않습니다. 경로를 확인하세요.")

# --- 요청 데이터 준비 ---
with IMG_PATH.open("rb") as img_file:
    files = {"image": (IMG_PATH.name, img_file, "image/jpeg")}  # 확장자에 따라 Content-Type 조정 가능
    data = {"question": QUESTION}
    if CONVERSATION_ID:
        data["conversation_id"] = CONVERSATION_ID

    print("📤 분석 요청 중...")
    response = requests.post(API_URL, files=files, data=data)

# --- 응답 처리 ---
print(f"HTTP 상태코드: {response.status_code}")
try:
    res_json = response.json()
    print("✅ 응답 결과:", res_json)
except ValueError:
    print("❌ JSON 파싱 오류:", response.text)
