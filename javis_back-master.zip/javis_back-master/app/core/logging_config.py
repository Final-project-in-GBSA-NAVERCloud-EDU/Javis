# app/core/logging_config.py

import logging
import logging.config
import sys

LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,

    "formatters": {
        "detailed": {
            "format": "[%(asctime)s] %(levelname)s %(name)s %(module)s:%(lineno)d - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
        "simple": {
            "format": "%(levelname)s %(name)s - %(message)s",
        },
    },

    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "detailed",
            "stream": sys.stdout,
            "level": "INFO",
        },
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "formatter": "detailed",
            "filename": "logs/app.log",
            "maxBytes": 10 * 1024 * 1024,
            "backupCount": 5,
            "encoding": "utf-8",
            "level": "DEBUG",
        },
    },

    "loggers": {
        # FastAPI / Starlette
        "uvicorn": {"handlers": ["console", "file"], "level": "INFO", "propagate": False},
        "uvicorn.error": {"handlers": ["console", "file"], "level": "ERROR", "propagate": False},
        "uvicorn.access": {"handlers": ["console"], "level": "INFO", "propagate": False},

        # SQLAlchemy
        "sqlalchemy.engine": {"handlers": ["console", "file"], "level": "INFO", "propagate": False},

        # 애플리케이션 루트 로거
        "": {"handlers": ["console", "file"], "level": "INFO"},
    },
}

def setup_logging():
    logging.config.dictConfig(LOGGING_CONFIG)
