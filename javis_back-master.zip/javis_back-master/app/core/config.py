import os
from urllib.parse import quote_plus

from dotenv import load_dotenv

load_dotenv()

class Settings:
    CLOVA_API_KEY: str = os.getenv("CLOVA_API_KEY")
    CLOVA_HOST: str = os.getenv("CLOVA_HOST")

    # 챗봇(텍스트) 모델
    CLOVA_CHAT_MODEL_ID  = os.getenv("CLOVA_CHAT_MODEL_ID")
    CLOVA_CHAT_API_PATH  = os.getenv("CLOVA_CHAT_API_PATH", "v1")

    # 비전(이미지) 모델
    CLOVA_VISION_MODEL_ID = os.getenv("CLOVA_VISION_MODEL_ID")
    CLOVA_VISION_API_PATH = os.getenv("CLOVA_VISION_API_PATH", "v3")

    # Naver Maps API (길찾기 & 지오코딩)
    NAVER_MAP_CLIENT_ID: str = os.getenv("NAVER_MAP_CLIENT_ID")
    NAVER_MAP_CLIENT_SECRET: str = os.getenv("NAVER_MAP_CLIENT_SECRET")

    NCLOUD_ACCESS_KEY: str = os.getenv("NCLOUD_ACCESS_KEY")
    NCLOUD_SECRET_KEY: str = os.getenv("NCLOUD_SECRET_KEY")
    NCLOUD_BUCKET: str = os.getenv("NCLOUD_BUCKET")
    NCLOUD_S3_ENDPOINT: str = os.getenv("NCLOUD_S3_ENDPOINT")

    MYSQL_HOST: str = os.getenv("MYSQL_HOST")
    MYSQL_USER: str = os.getenv("MYSQL_USER")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD")
    ENC_PW = quote_plus(MYSQL_PASSWORD)
    MYSQL_DB: str = os.getenv("MYSQL_DB")
    SQLALCHEMY_ECHO: bool = False

    API_BASE_URL: str = os.getenv("API_BASE_URL", "http://localhost:8000")

    ALLOW_ALL_ORIGINS = os.getenv("ALLOW_ALL_ORIGINS", "false").lower() == "true"
    ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "").split(",")

    NAVER_CLIENT_ID: str = os.getenv("NAVER_CLIENT_ID")
    NAVER_CLIENT_SECRET: str = os.getenv("NAVER_CLIENT_SECRET")
    NAVER_CALLBACK_URL: str = os.getenv("NAVER_CALLBACK_URL")
    LOGIN_REDIRECT_URL: str = os.getenv("LOGIN_REDIRECT_URL")

    JWT_SECRET_KEY: str = os.getenv("JWT_SECRET_KEY")
    JWT_ALGORITHM: str = os.getenv("JWT_ALGORITHM", "HS256")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 60))

    class Config:
        env_file = ".env"

    SQLALCHEMY_DATABASE_URI: str = (
        f"mysql+asyncmy://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}/{MYSQL_DB}"
    )
settings = Settings()
