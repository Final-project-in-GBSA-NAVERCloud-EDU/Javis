import uuid, datetime as dt
from sqlalchemy import Column, String, Text, DateTime, BigInteger, Integer, ForeignKey, Boolean
from sqlalchemy.dialects.mysql import JSON, DATETIME
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()

class Conversation(Base):
    __tablename__ = "conversations"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    title = Column(String(255))
    created_at = Column(DateTime, default=dt.datetime.utcnow)
    updated_at = Column(DateTime, default=dt.datetime.utcnow, onupdate=dt.datetime.utcnow)
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")

class Message(Base):
    __tablename__ = "messages"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    conversation_id = Column(String(36), ForeignKey("conversations.id"), nullable=False)
    sender = Column(String(10), ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    sources = Column(JSON)
    created_at = Column(DATETIME(fsp=3), default=lambda : dt.datetime.utcnow())
    conversation = relationship("Conversation", back_populates="messages")


class UploadedImage(Base):
    __tablename__ = "uploaded_images"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    conversation_id = Column(String(36), ForeignKey("conversations.id"), nullable=True)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=True)
    path = Column(String(512), nullable=False)
    url = Column(String(512), nullable=False)
    width = Column(Integer, nullable=False)
    height = Column(Integer, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DATETIME(fsp=3), nullable=False, default=lambda : dt.datetime.utcnow())

class User(Base):
    __tablename__ = "users"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    naver_id = Column(String(255), unique=True, nullable=True, index=True)  # NAVER ID
    email = Column(String(255), nullable=True, index=True)  # 사용자 email
    nickname = Column(String(255), nullable=True, index=True)  # 사용자 별명
    profileImage = Column(String(255), nullable=True)   # 사용자 프로필 이미지 URL
    is_admin = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, default=dt.datetime.utcnow)
    updated_at = Column(DateTime, default=dt.datetime.utcnow, onupdate=dt.datetime.utcnow)

    def __repr__(self):
        return f"User(id={self.id}, naver_id={self.naver_id}, email={self.email}, nickname={self.nickname}), profileImage={self.profileImage}, phone={self.phone}, is_admin={self.is_admin} ,created_at={self.created_at}, updated_at={self.updated_at})"