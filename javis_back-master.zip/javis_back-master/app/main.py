from fastapi import FastAPI, APIRouter
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.routers import chat, analyze, route, conversations, auth
from app.core.logging_config import setup_logging

setup_logging()
app = FastAPI(debug=True)
api = APIRouter(prefix="/api")

api.include_router(chat.router)
api.include_router(analyze.router)
api.include_router(route.router)
api.include_router(conversations.router)
api.include_router(auth.router)

app.include_router(api)

if settings.ALLOW_ALL_ORIGINS:
    allow_origins = ["*"]
else:
    allow_origins = settings.ALLOWED_ORIGINS

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Javis Back 정상 작동 중"}