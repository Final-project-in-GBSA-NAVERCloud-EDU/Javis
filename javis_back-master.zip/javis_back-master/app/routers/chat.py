from fastapi import APIRouter, HTTPException, Depends, Form
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db import get_db
from app.models import Conversation, Message
import httpx
import json
import re
from app.core.config import settings
from datetime import datetime, timezone  # datetime, timezone 임포트 추가

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatRequest(BaseModel):
    conversation_id: str | None = None
    prompt: str


class ChatResponse(BaseModel):
    content: str
    conversation_id: str


@router.post("", response_model=ChatResponse)
async def chat(request: ChatRequest, db: AsyncSession = Depends(get_db)):
    # 대화 세션 생성 또는 조회
    if request.conversation_id:
        conv = await db.get(Conversation, request.conversation_id)
        if conv is None:
            raise HTTPException(status_code=404, detail="대화 세션이 존재하지 않습니다.")
    else:
        conv = Conversation(title="새 채팅")
        db.add(conv)
        await db.flush()  # id 확보

    # 사용자 메시지 저장
    user_msg = Message(
        conversation_id=conv.id,
        sender="user",
        content=request.prompt
    )
    db.add(user_msg)
    # conv.updated_at 업데이트 (★★ 새로 추가 ★★)
    conv.updated_at = datetime.now(timezone.utc)  # 현재 UTC 시간으로 업데이트
    db.add(conv)  # 변경사항을 세션에 추가

    # --- 이전 대화 맥락 조회 및 Clova Studio 페이로드 구성 (동일) ---
    prev_msgs_rs = await db.execute(
        select(Message)
        .where(Message.conversation_id == conv.id)
        .order_by(Message.created_at.desc())
        .limit(9)
    )
    prev_msgs = prev_msgs_rs.scalars().all()
    prev_msgs.reverse()

    clova_messages = [
        {
            "role": "system",
            "content": """
당신은 서울 여행에 특화된 가이드 챗봇입니다. 응답은 200자 내외로 해주고, 응답이 길어질 경우 다음 질의에 이어서 계속 답해줘. 여행 정보니까 주소나 경로는 마스킹하지 않고 제공해줘.
"""
        }
    ]

    # --- Few-shot Learning 예시 추가 (JSON 백틱 수정) ---
    clova_messages.append({"role": "user", "content": "서울역에서 남산타워까지 가는 길 알려줘"})
    clova_messages.append({"role": "assistant", "content": """```json
{
  "action": "route",
  "origin": "서울역",
  "destination": "남산타워",
  "message": "서울역에서 남산타워까지의 경로를 안내해 드릴게요."
}
```"""})

    clova_messages.append({"role": "user", "content": "강남역 1번 출구에서 잠실 롯데월드까지 어떻게 가?"})
    clova_messages.append({"role": "assistant", "content": """```json
{
  "action": "route",
  "origin": "강남역 1번 출구",
  "destination": "잠실 롯데월드",
  "message": "강남역 1번 출구에서 잠실 롯데월드까지의 경로를 찾아드릴게요."
}
```"""})

    # 이전 메시지들을 Clova Studio 형식으로 변환하여 추가
    for msg in prev_msgs:
        if msg.sender == "user" and msg.content == request.prompt:
            continue
        clova_messages.append({"role": msg.sender, "content": msg.content})

    clova_messages.append({"role": "user", "content": request.prompt})

    payload = {
        "model": settings.CLOVA_CHAT_MODEL_ID,
        "messages": clova_messages,
        "maxTokens": 1024
    }
    # --- Clova Studio 페이로드 구성 끝 ---

    # LLM 호출
    url = f"{settings.CLOVA_HOST}/testapp/{settings.CLOVA_CHAT_API_PATH}/chat-completions/{settings.CLOVA_CHAT_MODEL_ID}"
    headers = {
        "Authorization": settings.CLOVA_API_KEY,
        "X-NCP-CLOVASTUDIO-REQUEST-ID": settings.CLOVA_CHAT_MODEL_ID,
        "Content-Type": "application/json; charset=utf-8",
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        res = await client.post(url, headers=headers, json=payload)
    if res.status_code != 200:
        raise HTTPException(status_code=502, detail=f"Clova API Error: {res.text}")

    data = res.json()
    clova_response_content = data["result"]["message"]["content"]

    final_content = clova_response_content

    # Clova Studio 응답 파싱 및 분기 처리
    try:
        # Markdown 코드 블록에서 JSON 문자열 추출
        json_match = re.search(r"```json\n(.*?)```", clova_response_content, re.DOTALL)
        if json_match:
            json_string = json_match.group(1)
            parsed_clova_response = json.loads(json_string)
        else:
            # Markdown 블록이 없으면 일반 JSON 파싱 시도 (이전 로직)
            parsed_clova_response = json.loads(clova_response_content)

        if parsed_clova_response.get("action") == "route":
            origin = parsed_clova_response.get("origin")
            destination = parsed_clova_response.get("destination")
            message_for_user = parsed_clova_response.get("message", "경로를 안내해 드릴게요.")

            if origin and destination:
                route_api_url = "Https://javis.shop/api/route"
                route_params = {"origin": origin, "destination": destination}

                async with httpx.AsyncClient(timeout=10.0) as route_client:
                    route_res = await route_client.get(route_api_url, params=route_params)

                if route_res.status_code == 200:
                    route_data_from_route_api = route_res.json()
                    route_url = route_data_from_route_api.get("route_url")

                    if route_url:
                        final_content = f"{message_for_user}\n[네이버 지도에서 보기]({route_url})"
                    else:
                        final_content = f"경로 URL을 가져오는데 실패했습니다."
                else:
                    final_content = f"경로 정보를 가져오는데 실패했습니다: {route_res.text}"
            else:
                final_content = "경로 안내를 위해 출발지와 도착지 정보가 필요합니다."
    except json.JSONDecodeError:
        pass
    except Exception as e:
        print(f"Error processing Clova response for route: {e}")
        pass

    # assistant 메시지 저장
    bot_msg = Message(
        conversation_id=conv.id,
        sender="assistant",
        content=final_content
    )
    db.add(bot_msg)
    # conv.updated_at 업데이트
    conv.updated_at = datetime.now(timezone.utc)  # 현재 UTC 시간으로 업데이트
    db.add(conv)  # 변경사항을 세션에 추가

    await db.commit()

    return ChatResponse(content=final_content, conversation_id=conv.id)