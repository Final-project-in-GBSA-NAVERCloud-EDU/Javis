import re
import boto3
import httpx
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc

from fastapi import APIRouter, Depends, HTTPException, status

from app.core.config import settings
from pydantic import BaseModel
from app.db import get_db
from app.models import Conversation, Message, UploadedImage, User
from typing import List, Optional

from app.dependencies import get_current_user  # get_current_user 임포트

router = APIRouter(prefix="/conversations", tags=["conversations"])


# Pydantic 모델 (기존과 동일)
class ConversationItem(BaseModel):
    id: str
    title: Optional[str] = None
    path: Optional[str] = None
    created_at: Optional[str] = None  # ISO8601 문자열로
    updated_at: Optional[str] = None


class ConversationsResponse(BaseModel):
    conversations: List[ConversationItem]


class ConversationCreateResponse(BaseModel):
    conversation_id: str
    title: str


class ConversationDetailResponse(BaseModel):
    conversation_id: str
    title: Optional[str]
    created_at: str
    updated_at: str


class ConversationUpdateRequest(BaseModel):
    title: str


class ConversationUpdateResponse(BaseModel):
    conversation_id: str
    title: str
    message: str


class MessageItem(BaseModel):
    image_url: Optional[str] = None
    id: str
    sender: str
    content: str
    created_at: str
    type: str


class ImageItem(BaseModel):
    id: str
    url: str
    width: int
    height: int
    expires_at: str
    created_at: str


class ConversationDetailFullResponse(BaseModel):
    conversation_id: str
    title: Optional[str]
    created_at: str
    updated_at: str
    messages: List[MessageItem]
    images: List[ImageItem]


# /analyze 에서 가져온 공통 함수 (기존과 동일)
def s3_client():
    """NCP Object Storage 클라이언트를 생성하여 반환합니다."""
    return boto3.client(
        "s3",
        aws_access_key_id=settings.NCLOUD_ACCESS_KEY,
        aws_secret_access_key=settings.NCLOUD_SECRET_KEY,
        endpoint_url=settings.NCLOUD_S3_ENDPOINT,
        config=boto3.session.Config(signature_version="s3v4")
    )


# GET용 Pre-signed URL 생성 함수 새로 정의 (기존과 동일)
def generate_presigned_get_url(object_key: str, expiration: int = 3600) -> str | None:
    """
    DB에 저장된 Object Key(path)를 사용하여
    GET 요청을 위한 새로운 Pre-signed URL을 생성합니다.
    """
    if not object_key:
        return None

    s3 = s3_client()
    try:
        url = s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': settings.NCLOUD_BUCKET, 'Key': object_key},
            ExpiresIn=expiration  # 1시간 동안 유효한 URL
        )
        return url
    except Exception as e:
        # 실제 운영 환경에서는 로깅(logging) 처리를 권장합니다.
        print(f"Error generating presigned URL for {object_key}: {e}")
        return None


# 1) 대화 목록 조회 (기존과 동일)
@router.get("", response_model=ConversationsResponse)
async def get_conversations(
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    try:
        if current_user.is_admin:
            result = await db.execute(select(Conversation).order_by(desc(Conversation.updated_at)))
        else:
            result = await db.execute(
                select(Conversation)
                .where(Conversation.user_id == current_user.id)
                .order_by(desc(Conversation.updated_at))
            )
        convs = result.scalars().all()

        items = []
        for conv in convs:
            # 자동 제목 생성 로직 (기존과 동일)
            if conv.title == "새 채팅":
                messages_result = await db.execute(
                    select(Message)
                    .where(Message.conversation_id == conv.id)
                    .order_by(Message.created_at.asc())
                )
                all_messages = messages_result.scalars().all()

                if len(all_messages) >= 5:
                    llm_messages = [{"role": "system",
                                     "content": "다음 대화 내용을 요약하여 **10자 내외의 간결한 제목**을 생성해줘. **제목만 반환**해. 불필요한 설명이나 문장은 포함하지 마."}]
                    for msg in all_messages:
                        content_for_llm = msg.content.split('[이미지:')[0].strip()
                        llm_messages.append({"role": msg.sender, "content": content_for_llm})

                    payload = {
                        "model": settings.CLOVA_CHAT_MODEL_ID,
                        "messages": llm_messages,
                        "maxTokens": 1024
                    }
                    headers = {
                        "Authorization": settings.CLOVA_API_KEY,
                        "X-NCP-CLOVASTUDIO-REQUEST-ID": settings.CLOVA_CHAT_MODEL_ID,
                        "Content-Type": "application/json; charset=utf-8",
                    }
                    api = (
                        f"{settings.CLOVA_HOST}/testapp/"
                        f"{settings.CLOVA_CHAT_API_PATH}/"
                        f"chat-completions/{settings.CLOVA_CHAT_MODEL_ID}"
                    )

                    new_title = "새 채팅"
                    try:
                        async with httpx.AsyncClient(timeout=10) as client:
                            llm_res = await client.post(api, headers=headers, json=payload)
                        if llm_res.status_code == 200:
                            llm_data = llm_res.json()
                            generated_title = llm_data["result"]["message"]["content"].strip()
                            new_title = generated_title
                        else:
                            print(f"LLM 제목 생성 실패: {llm_res.status_code} - {llm_res.text}")
                    except Exception as llm_e:
                        print(f"LLM 제목 생성 중 예외 발생: {llm_e}")

                    conv.title = new_title
                    db.add(conv)
                    await db.commit()
                    await db.refresh(conv)

            items.append(
                ConversationItem(
                    id=conv.id, title=conv.title,
                    path=f"/conversations/{conv.id}",
                    created_at=conv.created_at.isoformat(),
                    updated_at=conv.updated_at.isoformat()
                )
            )
        return ConversationsResponse(conversations=items)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"DB 조회 중 오류: {str(e)}")


# 2) 신규 대화 생성 (기존과 동일)
@router.post("", status_code=status.HTTP_201_CREATED, response_model=ConversationCreateResponse)
async def create_conversation(
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_user)
):
    conv = Conversation(title="새 채팅", user_id=current_user.id)
    db.add(conv)
    await db.commit()
    await db.refresh(conv)
    return ConversationCreateResponse(conversation_id=conv.id, title=conv.title)


# 3) 특정 대화 정보 조회
@router.get("/{conversation_id}", response_model=ConversationDetailResponse)
async def get_conversation(
        conversation_id: str,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_user)  # 현재 사용자 정보 주입
):
    conv = await db.get(Conversation, conversation_id)
    if not conv:
        raise HTTPException(status_code=404, detail="대화가 존재하지 않습니다.")

    # 권한 확인 로직 추가
    if not current_user.is_admin and conv.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="권한이 없습니다.")

    return ConversationDetailResponse(
        conversation_id=conv.id,
        title=conv.title,
        created_at=conv.created_at.isoformat(),
        updated_at=conv.updated_at.isoformat()
    )


# 4) 특정 대화 전체 목록
@router.get("/{conversation_id}/full", response_model=ConversationDetailFullResponse)
async def get_conversation_full(
        conversation_id: str,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_user)  # 현재 사용자 정보 주입
):
    # 1. 대화 정보 조회
    conv = await db.get(Conversation, conversation_id)
    if not conv:
        raise HTTPException(status_code=404, detail="대화가 존재하지 않습니다.")

    # 권한 확인 로직 추가
    if not current_user.is_admin and conv.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="권한이 없습니다.")

    # 2. 메시지 리스트 조회 (기존과 동일)
    msg_rs = await db.execute(
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(Message.created_at.asc())
    )
    msgs = msg_rs.scalars().all()

    # 3. 이미지 리스트 조회 (기존과 동일)
    img_rs = await db.execute(
        select(UploadedImage)
        .where(UploadedImage.conversation_id == conversation_id)
        .order_by(UploadedImage.created_at.asc())
    )
    imgs = img_rs.scalars().all()

    image_map = {img.id: img for img in imgs}

    # 4. 메시지에 이미지 URL 포함 (기존과 동일)
    processed_messages = []
    for m in msgs:
        msg_content = m.content
        image_url = None

        image_id_match = re.search(r"\[이미지:(\S+)\]", msg_content)
        if image_id_match:
            image_id = image_id_match.group(1)
            image_record = image_map.get(image_id)

            if image_record:
                object_key = image_record.path
                image_url = generate_presigned_get_url(object_key)

                msg_content = msg_content.replace(f"\[이미지:{image_id}\]", "").strip()

        processed_messages.append(MessageItem(
            id=m.id,
            sender=m.sender,
            content=msg_content,
            image_url=image_url,
            created_at=m.created_at.isoformat(),
            type='image' if image_url else 'text'
        ))

    # 5. 반환 (기존과 동일)
    return ConversationDetailFullResponse(
        conversation_id=conv.id,
        title=conv.title,
        created_at=conv.created_at.isoformat(),
        updated_at=conv.updated_at.isoformat(),
        messages=processed_messages,
        images=[]
    )


# 5) 대화 제목 수정
@router.put("/{conversation_id}", response_model=ConversationUpdateResponse)
async def update_conversation_title(
        conversation_id: str,
        req: ConversationUpdateRequest,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_user)  # 현재 사용자 정보 주입
):
    conv = await db.get(Conversation, conversation_id)
    if not conv:
        raise HTTPException(status_code=404, detail="대화가 존재하지 않습니다.")

    # 권한 확인 로직 추가
    if not current_user.is_admin and conv.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="권한이 없습니다.")

    if not req.title.strip():
        raise HTTPException(status_code=400, detail="제목을 입력하세요.")
    conv.title = req.title.strip()
    await db.commit()
    return ConversationUpdateResponse(conversation_id=conv.id, title=conv.title, message="제목이 수정되었습니다.")


# 6) 대화 삭제
@router.delete("/{conversation_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_conversation(
        conversation_id: str,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(get_current_user)  # 현재 사용자 정보 주입
):
    conv = await db.get(Conversation, conversation_id)
    if not conv:
        raise HTTPException(status_code=404, detail="대화가 존재하지 않습니다.")

    # 권한 확인 로직 추가
    if not current_user.is_admin and conv.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="권한이 없습니다.")

    await db.delete(conv)
    await db.commit()
    return None
