from fastapi import APIRouter, Query, HTTPException
from pydantic import BaseModel
import httpx
import urllib.parse
from app.core.config import settings
# import json  # 디버깅용으로 필요하면 유지

router = APIRouter(prefix="/route", tags=["route"])


class RouteResponse(BaseModel):
    route_url: str  # 웹 뷰 URL만 반환


@router.get("", response_model=RouteResponse)
async def get_route(
        origin: str = Query(..., description="출발지 명칭 또는 주소"),
        destination: str = Query(..., description="도착지 명칭 또는 주소"),
):
    if not origin.strip() or not destination.strip():
        raise HTTPException(status_code=400, detail="origin과 destination을 모두 전달해야 합니다.")

    geo_url = "https://maps.apigw.ntruss.com/map-geocode/v2/geocode"
    headers = {
        "x-ncp-apigw-api-key-id": settings.NAVER_MAP_CLIENT_ID,
        "x-ncp-apigw-api-key": settings.NAVER_MAP_CLIENT_SECRET
    }

    async def get_coordinates(query_str: str):
        async with httpx.AsyncClient() as client:
            geo_res = await client.get(geo_url, headers=headers, params={"query": query_str}, timeout=10.0)
            geo_data = geo_res.json()

        # 디버깅용 print (필요 없으면 제거)
        # print(f"Geocoding result for '{query_str}':")
        # print(json.dumps(geo_data, indent=2, ensure_ascii=False))

        if geo_data.get("addresses"):
            return geo_data["addresses"][0]["x"], geo_data["addresses"][0]["y"]
        elif geo_data.get("jibeons"):
            return geo_data["jibeons"][0]["x"], geo_data["jibeons"][0]["y"]
        elif geo_data.get("roads"):
            return geo_data["roads"][0]["x"], geo_data["roads"][0]["y"]

        return None, None

    start_x, start_y = await get_coordinates(origin)
    if not start_x:
        raise HTTPException(status_code=404, detail=f"출발지 '{origin}' 검색 결과가 없습니다.")

    goal_x, goal_y = await get_coordinates(destination)
    if not goal_y:
        raise HTTPException(status_code=404, detail=f"도착지 '{destination}' 검색 결과가 없습니다.")

    # --- 웹 뷰 URL 생성 로직 (★★ 이 부분 전체를 교체 ★★) ---
    # 우선순위: transit -> walk
    transport_modes_web = ["transit", "walk"]

    for mode in transport_modes_web:
        route_url = (
            f"https://map.naver.com/p/directions/"
            f"{start_x},{start_y},{urllib.parse.quote(origin)},-,PLACE_POI/"
            f"{goal_x},{goal_y},{urllib.parse.quote(destination)},-,PLACE_POI/-/{mode}"
            f"?version=3"  # 모바일 뷰 방지 파라미터
        )

        # 여기서는 실제 API 호출로 경로 유효성을 검증하지 않습니다.
        # 웹 뷰 URL만 생성하여 반환합니다.
        # 만약 특정 경로가 웹 뷰에서 유효하지 않을 경우, 프론트엔드에서 iframe 로드 실패로 처리되거나
        # 사용자에게 "경로 없음" 메시지를 보여주는 로직이 필요할 수 있습니다.

        # 일단은 URL을 생성하면 성공으로 간주하고 반환합니다.
        return RouteResponse(
            route_url=route_url
        )

    # 이 부분은 실행되지 않을 것이지만, 혹시 모를 상황에 대비
    raise HTTPException(status_code=500, detail="경로 URL 생성에 실패했습니다.")
