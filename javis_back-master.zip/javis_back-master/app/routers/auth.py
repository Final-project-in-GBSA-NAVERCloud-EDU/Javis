import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional, Annotated

import httpx
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import RedirectResponse
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from pydantic import BaseModel # Pydantic BaseModel 임포트

from app.core.config import settings
from app.core.security import create_access_token, decode_access_token

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db import get_db
from app.models import User

router = APIRouter(prefix="/auth", tags=["auth"])

# Pydantic User 스키마 정의
class UserRead(BaseModel):
    id: uuid.UUID # UUID 타입으로 변경
    naver_id: str
    email: Optional[str] = None
    nickname: Optional[str] = None
    profileImage: Optional[str] = None
    is_admin: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True # orm_mode 대신 from_attributes 사용 (Pydantic v2)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/token")

async def get_current_user(token: Annotated[str, Depends(oauth2_scheme)], db: AsyncSession = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_access_token(token)
        if payload is None:
            raise credentials_exception
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user_query = await db.execute(select(User).filter_by(id=user_id))
    user = user_query.scalars().first()
    if user is None:
        raise credentials_exception
    return user

@router.get("/login")
async def naver_login_start():
    state = str(uuid.uuid4())

    naver_login_url = (
        f"https://nid.naver.com/oauth2.0/authorize?"
        f"response_type=code&client_id={settings.NAVER_CLIENT_ID}&"
        f"redirect_uri={settings.NAVER_CALLBACK_URL}&"
        f"state={state}"
    )
    return RedirectResponse(naver_login_url)

@router.get("/callback")
async def naver_login_callback(
        code: str,
        state: str,
        db: AsyncSession = Depends(get_db)
):
    token_url = "https://nid.naver.com/oauth2.0/token"
    token_data = {
        "grant_type": "authorization_code",
        "client_id": settings.NAVER_CLIENT_ID,
        "client_secret": settings.NAVER_CLIENT_SECRET,
        "redirect_uri": settings.NAVER_CALLBACK_URL,
        "code": code,
        "state": state
    }
    async with httpx.AsyncClient() as client:
        token_res = await client.post(token_url, data=token_data)
    if token_res.status_code != 200:
        print(f"Naver Token Error: {token_res.status_code} - {token_res.text}")
        raise HTTPException(status_code=500, detail=f"Failed to get Naver token: {token_res.text}")

    access_token = token_res.json().get("access_token")
    if not access_token:
        print(f"Access token not found in Naver token response: {token_res.json()}")
        raise HTTPException(status_code=500, detail="Access token not found in Naver token response")

    user_info_url = "https://openapi.naver.com/v1/nid/me"
    headers = {"Authorization": f"Bearer {access_token}"}
    async with httpx.AsyncClient() as client:
        user_info_res = await client.get(user_info_url, headers=headers)

    if user_info_res.status_code != 200:
        print(f"Naver User Info Error: {user_info_res.status_code} - {user_info_res.text}")
        raise HTTPException(status_code=500, detail=f"Failed to get Naver user info: {user_info_res.text}")

    user_info = user_info_res.json().get("response")
    if not user_info:
        raise HTTPException(status_code=500, detail="User info not found in Naver user info response")

    naver_id = user_info.get("id")
    nickname = user_info.get("nickname")
    email = user_info.get("email")
    profile_image = user_info.get("profile_image")

    user_query = await db.execute(select(User).filter_by(naver_id=naver_id))
    user = user_query.scalars().first()

    if not user:
        user = User(
            naver_id=naver_id,
            email=email,
            nickname=nickname,
            profileImage=profile_image,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
        print(f"New User Created: {user.nickname} ({user.email})")
    else:
        print(f"Signin User: {user.nickname} ({user.email})")

    access_token = create_access_token(data={"sub": str(user.id)})
    print(f"Generated Access Token: {access_token}")

    redirect_to_frontend_url = f"{settings.LOGIN_REDIRECT_URL}?token={access_token}"

    return RedirectResponse(redirect_to_frontend_url)

# response_model을 UserRead로 변경
@router.get("/accounts/me", response_model=UserRead)
async def read_users_me(current_user: Annotated[User, Depends(get_current_user)]):
    return current_user