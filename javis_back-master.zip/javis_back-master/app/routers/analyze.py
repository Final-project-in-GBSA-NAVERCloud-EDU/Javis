import uuid, httpx, boto3, requests, io
from mimetypes import guess_type
from fastapi import APIRouter, UploadFile, Form, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.config import settings
from app.db import get_db
from app.models import Conversation, Message, UploadedImage
from PIL import Image
import re
from datetime import datetime, timezone, timedelta

router = APIRouter(prefix="/analyze", tags=["analyze"])


def s3_client():
    return boto3.client(
        "s3",
        aws_access_key_id=settings.NCLOUD_ACCESS_KEY,
        aws_secret_access_key=settings.NCLOUD_SECRET_KEY,
        endpoint_url=settings.NCLOUD_S3_ENDPOINT,
        config=boto3.session.Config(signature_version="s3v4")
    )


def upload_and_get_url(file_bytes: bytes, orig_name: str) -> tuple[str, str]:
    content_type, _ = guess_type(orig_name)
    if content_type is None:
        content_type = "application/octet-stream"

    now = datetime.utcnow()
    key_prefix = now.strftime("%Y/%m/%d/%H/%M/")
    object_key = f"{key_prefix}{uuid.uuid4()}_{orig_name}"

    s3 = s3_client()

    presigned_put = s3.generate_presigned_url(
        'put_object',
        Params={'Bucket': settings.NCLOUD_BUCKET, 'Key': object_key, 'ContentType': content_type},
        ExpiresIn=300
    )

    resp = requests.put(presigned_put, data=file_bytes, headers={"Content-Type": content_type})
    if not resp.ok:
        raise HTTPException(status_code=502, detail=f"S3 업로드 실패: {resp.status_code} {resp.text}")

    url = s3.generate_presigned_url(
        "get_object",
        Params={"Bucket": settings.NCLOUD_BUCKET, "Key": object_key},
        ExpiresIn=3600
    )
    return url, object_key


def generate_presigned_get_url(object_key: str, expiration: int = 3600) -> str | None:
    if not object_key:
        return None
    s3 = s3_client()
    try:
        url = s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': settings.NCLOUD_BUCKET, 'Key': object_key},
            ExpiresIn=expiration
        )
        return url
    except Exception as e:
        print(f"Error generating presigned URL for {object_key}: {e}")
        return None


class AnalyzeResponse(BaseModel):
    conversation_id: str
    place_name: str | None
    answer: str


@router.post("", response_model=AnalyzeResponse)
async def analyze(
        image: UploadFile,
        question: str = Form(...),
        conversation_id: str | None = Form(None),
        db: AsyncSession = Depends(get_db),
):
    if not conversation_id:
        conv = Conversation(title="새 채팅")
        db.add(conv)
        await db.flush()
        conversation_id = conv.id
    else:
        conv = await db.get(Conversation, conversation_id)
        if not conv:
            raise HTTPException(status_code=404, detail="대화 세션이 존재하지 않습니다.")

    img_bytes = await image.read()
    img_url, object_key = upload_and_get_url(img_bytes, image.filename)

    img_stream = io.BytesIO(img_bytes)
    img_obj = Image.open(img_stream)
    width, height = img_obj.width, img_obj.height

    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(hours=1)

    user_id = getattr(conv, "user_id", None)

    upload_img = UploadedImage(
        id=str(uuid.uuid4()),
        user_id=user_id,
        conversation_id=conversation_id,
        path=object_key,
        url=img_url,
        width=width,
        height=height,
        expires_at=expires_at,
        created_at=now,
    )
    db.add(upload_img)

    user_message_content = f"{question} [이미지:{upload_img.id}]"
    user_msg = Message(conversation_id=conversation_id, sender="user", content=user_message_content)
    db.add(user_msg)
    conv.updated_at = datetime.now(timezone.utc)
    db.add(conv)

    # --- 이전 대화 맥락 조회 및 Clova Studio 페이로드 구성 ---
    prev_msgs_rs = await db.execute(
        select(Message)
        .where(Message.conversation_id == conv.id)
        .order_by(Message.created_at.desc())
        .limit(9)
    )
    prev_msgs = prev_msgs_rs.scalars().all()
    prev_msgs.reverse()

    clova_messages = [
        {
            "role": "system",
            "content": """
당신은 서울 여행에 특화된 가이드 챗봇입니다. 사용자가 경로 안내를 요청할 때, 출발지나 도착지가 지명(예: '서울역', '남산타워')인 경우,
**반드시 사용자에게 해당 지명의 정확한 주소를 확인하거나, 가장 대표적인 주소를 제안하여 확인을 요청해야 합니다.**
예를 들어, '서울역'이라고 하면 '서울역의 정확한 주소는 서울특별시 중구 세종대로 18입니다.
이 주소로 안내해 드릴까요?'와 같이 응답해주세요. 사용자가 주소를 제공하면 해당 주소를 사용하여 경로를 안내합니다.
**주소나 경로는 절대로 마스킹하지 않고 제공해야 합니다.**

JSON 형식 예시:
{
   "action": "route",
   "origin": "출발지 주소 또는 명칭",
   "destination": "도착지 주소 또는 명칭",
   "message": "요청하신 경로를 안내해 드릴게요."
}
**절대 주소나 경로 정보를 마스킹하지 마세요.**
모든 주소와 경로는 명확하게 제공되어야 합니다.
응답은 200자 내외로 해주세요. 응답이 길어질 경우 다음 질의에 이어서 계속 답해주세요.
"""
        }
    ]

    # --- Few-shot Learning 예시 추가 (JSON 백틱 수정) ---
    clova_messages.append({"role": "user", "content": "서울역에서 남산타워까지 가는 길 알려줘"})
    clova_messages.append({"role": "assistant", "content": """```json
{
  "action": "route",
  "origin": "서울역",
  "destination": "남산타워",
  "message": "서울역에서 남산타워까지의 경로를 안내해 드릴게요."
}
```"""})

    clova_messages.append({"role": "user", "content": "강남역 1번 출구에서 잠실 롯데월드까지 어떻게 가?"})
    clova_messages.append({"role": "assistant", "content": """```json
{
  "action": "route",
  "origin": "강남역 1번 출구",
  "destination": "잠실 롯데월드",
  "message": "강남역 1번 출구에서 잠실 롯데월드까지의 경로를 찾아드릴게요."
}
```"""})

    # 이전 메시지들을 Clova Studio 형식으로 변환하여 추가
    for msg in prev_msgs:
        msg_content_for_clova = msg.content

        # 메시지 내용에서 [이미지:ID] 패턴 찾기
        image_id_match = re.search(r"\[이미지:(\S+)\]", msg_content_for_clova)
        if image_id_match:
            image_id = image_id_match.group(1)
            img_rs = await db.execute(
                select(UploadedImage)
                .where(UploadedImage.conversation_id == conversation_id)
                .order_by(UploadedImage.created_at.asc())
            )
            imgs = img_rs.scalars().all()
            image_map = {img.id: img for img in imgs}

            image_record = image_map.get(image_id)
            if image_record:
                object_key_for_clova = image_record.path
                image_url_for_clova = generate_presigned_get_url(object_key_for_clova)

                if image_url_for_clova:
                    msg_content_for_clova = f"[이미지] {image_url_for_clova}\n{msg_content_for_clova.replace(f'[이미지:{image_id}]', '').strip()}"
                else:
                    msg_content_for_clova = msg_content_for_clova.replace(f'[이미지:{image_id}]', '').strip()
            else:
                msg_content_for_clova = msg_content_for_clova.replace(f'[이미지:{image_id}]', '').strip()

        if msg.sender == "user" and msg.content == user_message_content:
            continue

        clova_messages.append({"role": msg.sender, "content": msg_content_for_clova})

    clova_messages.append({"role": "user", "content": f"[이미지] {img_url}\n{question}"})

    payload = {
        "model": settings.CLOVA_VISION_MODEL_ID,
        "messages": clova_messages,
        "maxTokens": 1024
    }

    # --- Clova Studio 페이로드 구성 끝 ---
    headers = {
        "Authorization": settings.CLOVA_API_KEY,
        "X-NCP-CLOVASTUDIO-REQUEST-ID": settings.CLOVA_VISION_MODEL_ID,
        "Content-Type": "application/json; charset=utf-8",
    }
    api = (
        f"{settings.CLOVA_HOST}/testapp/"
        f"{settings.CLOVA_VISION_API_PATH}/"
        f"chat-completions/{settings.CLOVA_VISION_MODEL_ID}"
    )

    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(api, headers=headers, json=payload)
    if r.status_code != 200:
        raise HTTPException(status_code=502, detail=f"CLOVA 오류: {r.text}")

    answer = r.json()["result"]["message"]["content"]

    bot_msg = Message(conversation_id=conversation_id, sender="assistant", content=answer)
    db.add(bot_msg)
    conv.updated_at = datetime.now(timezone.utc)
    db.add(conv)

    await db.commit()

    return AnalyzeResponse(conversation_id=conversation_id, place_name=None, answer=answer)
