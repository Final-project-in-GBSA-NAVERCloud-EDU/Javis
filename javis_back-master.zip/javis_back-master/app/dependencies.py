from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.core.security import decode_access_token # JWT 토큰 디코딩 함수
from app.db import get_db # 데이터베이스 세션
from app.models import User # User 모델

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/callback") # 토큰을 얻을 엔드포인트 (실제 백엔드 토큰 발급 URL에 맞게 수정 필요)

async def get_current_user(
     token: str = Depends(oauth2_scheme),
     db: AsyncSession = Depends(get_db)
) -> User:
     credentials_exception = HTTPException(
         status_code=status.HTTP_401_UNAUTHORIZED,
         detail="Could not validate credentials",
         headers={"WWW-Authenticate": "Bearer"},
     )
     try:
         payload = decode_access_token(token)
         user_id: str = payload.get("sub")
         if user_id is None:
             raise credentials_exception
     except Exception:
         raise credentials_exception

     result = await db.execute(select(User).filter(User.id == user_id))
     user = result.scalars().first()

     if user is None:
         raise credentials_exception
     return user

async def get_current_admin_user(current_user: User = Depends(get_current_user)) -> User:
     if not current_user.is_admin:
         raise HTTPException(
             status_code=status.HTTP_403_FORBIDDEN,
             detail="Not enough permissions"
         )
     return current_user