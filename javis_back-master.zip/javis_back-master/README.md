### 1. 프로젝트 폴더 생성
```
mkdir traveljavis-project
cd traveljavis-project
```

### 2. Python 가상환경 생성
```
python3 -m venv traveljavis
```

### 3. 가상환경 활성화
```
source traveljavis/bin/activate
```

### (Windows의 경우)
```
.\traveljavis\Scripts\activate
```

### 4. GitHub 레포 클론
```
git clone git@github.com:lys0611/javis_back.git
```

### 5. 레포 폴더로 이동
```
cd javis_back
```

### 6. requirements.txt 있으면 설치
```
pip install -r requirements.txt
```
